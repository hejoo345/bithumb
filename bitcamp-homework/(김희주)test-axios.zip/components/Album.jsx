import React from 'react';
import styled from 'styled-components';
const Album = ({id, title, thumbnailUrl, url}) => {
    return(
            <AlbumDiv>
                <div><img src={thumbnailUrl} alt={title}></img></div>
                <div>
                    <p>{id}, {title}</p>
                    <a href={url}>{url}</a>
                </div>
            </AlbumDiv>
    )};

    const AlbumDiv = styled.div`
        background-color: white;
        border-radius: 12px;
        width: 400px;
        margin: 1em;
        padding: 0.5em;
    `;

export default Album;